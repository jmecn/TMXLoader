//
//  SKNode+WBUtils.h
//  SKTiledMap
//
//  Created by JasioWoo on 15/6/6.
//  Copyright (c) 2015年 JasioWoo. All rights reserved.
//

#import <SpriteKit/SpriteKit.h>

@interface SKNode (WBUtils)


- (CGFloat)globalZPosition;
- (void)setupGlobalZPosition:(CGFloat)gZPos;



@end
