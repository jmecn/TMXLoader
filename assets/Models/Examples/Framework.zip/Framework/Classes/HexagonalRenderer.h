//
//  HexagonalRenderer.h
//  SKTiledMap
//
//  Created by JasioWoo on 15/6/4.
//  Copyright (c) 2015年 JasioWoo. All rights reserved.
//

#import "StaggeredRenderer.h"

@interface HexagonalRenderer : StaggeredRenderer






@end
