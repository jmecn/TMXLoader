//
//  IsometricRenderer.h
//  SKTiledMap
//
//  Created by JasioWoo on 15/5/29.
//  Copyright (c) 2015年 JasioWoo. All rights reserved.
//

#import "SKMapRenderer.h"

@interface IsometricRenderer : SKMapRenderer

@end
